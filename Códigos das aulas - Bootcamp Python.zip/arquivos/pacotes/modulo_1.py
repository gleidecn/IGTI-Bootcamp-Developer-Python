def facao_isso():
    print('[modulo_1] faca_isso()')

class FacaIsso:
    pass