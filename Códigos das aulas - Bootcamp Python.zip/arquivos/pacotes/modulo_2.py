def faca_isso_tambem():
    print('[modulo_2] faca_isso_tambem()')

class FacaIssoTambem:
    pass