def print_boas_vindas(nome):
    print("Olá, {}. Tudo bem com você? ".format(nome))
